package com.fci.advanced.se.OrdersNotificationsManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersNotificationsManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
