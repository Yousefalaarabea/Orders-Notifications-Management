package com.fci.advanced.se.OrdersNotificationsManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdersNotificationsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrdersNotificationsManagementApplication.class, args);
	}

}
