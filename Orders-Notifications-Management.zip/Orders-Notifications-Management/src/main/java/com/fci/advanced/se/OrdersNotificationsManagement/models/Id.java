package com.fci.advanced.se.OrdersNotificationsManagement.models;

public @interface Id {
}
